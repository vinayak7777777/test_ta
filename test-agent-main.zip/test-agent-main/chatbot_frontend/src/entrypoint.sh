#!/bin/bash

# Run any setup steps or pre-processing tasks here
echo "Starting bank chatbot frontend..."

# Run the ETL script
streamlit run main.py
